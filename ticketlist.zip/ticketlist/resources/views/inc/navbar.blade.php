 <nav class="navbar navbar-expand-md navbar-dark bg-dark">
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarCollapse">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link {{ Request::is('/') ? 'active' : ''  }}" href="/">STS 1.0</a>
      </li>
      <li class="nav-item {{ Request::is('todo/create') ? 'active' : ''  }}">
        <a class="nav-link" href="todo/create">Create</a>
      </li>
  <!--<li class="nav-item {{ Request::is('todo/tune') ? 'active' : ''  }}">
        <a class="nav-link" href="todo/tune">Ticket</a>
      </li>-->

      <li class="nav-item {{ Request::is('mypag') ? 'active' : ''  }}">
        <a class="nav-link" href="todo/list">Archive Tickets</a>
      </li>

         <li class="nav-item {{ Request::is('search') ? 'active' : ''  }}">
        <a class="nav-link" href="todo/search">Search Tickets</a>
      </li>

    </ul>
   
  </div>
</nav>
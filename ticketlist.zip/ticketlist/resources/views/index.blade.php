@extends('layouts.app')

@section('content')
<h1>Support Ticket System</h1>
<hr/>

			<!--Search UI
		<div class="form-inline pull-right">
					<form action="" method="GET" class="form-inline pull-right">

			          

			                <label class="sr-only" for="search">Search</label>
			                <input type="text" align="pull-right" class="form-control" name="id" id="search" placeholder="Search">
			<br/>

			            <button type="submit"  class="btn btn-lg btn-success">
			            <span class="glyphicons glyphicons-search" align="right" aria-hidden="true"></span>Search
			            </button>

			        </form>
			    </div>
-->
		@if(count($todos)>0)
				@foreach($todos as $todo)

						<div class="card m-2">
							<h2><a href="todo/show/{{$todo->id}}"> {{$todo->title}}</a></h2>	
							<h2><div class="badge badge-success mt-4">{{ $todo->ticket}}</div></h2>
						<span class="badge badge-danger">{{$todo->due}}</span>
						</div>

				    	@endforeach

			@endif

		@endsection
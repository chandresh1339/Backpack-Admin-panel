<?php 
   

   if(!function_exists('alpha')){

		function alpha(){

			$randomid = mt_rand(100000,999999); 

			return 'A00'. $randomid; 

				   	}
   }

?>
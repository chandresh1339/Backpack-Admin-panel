<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/home', 'HomeController@index')->name('home');


Route::get('/','TodosController@index');

Route::resource('todos' , 'TodosController');

Route::get('todo/create' , 'TodosController@create');

Route::post('todo/store','TodosController@store');

Route::get('todo/show/{id}' , 'TodosController@show');


Route::get('todo/tune','TodosController@tune');

//Pagination 
Route::get('todo/list','PageController@list');


Auth::routes();


Route::get('todo/search','PageController@search');

//Admin page list
Route::resource('users' , 'AdminController');
Route::get('todo/lofusers','AdminController@lofusers');


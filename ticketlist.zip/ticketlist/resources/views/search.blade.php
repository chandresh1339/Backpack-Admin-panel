
@extends('layouts.app')

@section('content')

<body>


<form action="" method="GET" class="form-inline pull-right">
@csrf
            <div class="form-group form-group-lg has-feedback">

                <label class="sr-only" for="search">Search</label>
                <input type="text" class="form-control" name="search" id="search" placeholder="Search">

                <span class="glyphicons glyphicons-xl glyphicons-group form-control-feedback"></span>

            <button type="submit" class="btn btn btn-primary">
            <span class="glyphicons glyphicons-search" aria-hidden="true"></span>Search
            </button>
</div>
        </form>

        @foreach($todos as $item)
	<div class="card m-2">
	<h2> {{$item->title}}</h2>

		<h2><div class="badge badge-success mt-4">{{ $item->ticket}}</div>
		</h2>

		
</div>

@endforeach
</div>

    </body>

        @endsection
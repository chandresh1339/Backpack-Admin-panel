<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Todo;


class PageController extends Controller
{
    //
    function list()
    {	

    	$data=DB::table('todos')->paginate(5);
    	return view('mypag',['data'=>$data]);
    }

    public function search(Request $request)
  	{
      $search=$request->get('search');
      $todos=DB::table('todos')->where('ticket','like','%'.$search.'%')->paginate(10);
      return view('search',['todos'=>$todos]);
     }
}

@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Dashboard') }}</div>

 <span class="float-right"><a href="/todo/create" class="btn btn-secondary">Create a New Ticket</a></span>
                </div>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    
                    <h3>Your Tickets</h3>

                   @if(count($todos))
                        <table class="table table-striped">
                            <tr>
                                
                                <th>Created Tickets</th>
                                <th></th>
                            </tr>

                            @foreach($todos as $listing)
                            <tr>
                                <td>{{$listing->ticket}}</td>
                                <td>
                                    <form class="float-right ml-2" action="/listings/{{$listing->id }}" method="post">
                                        @csrf
                                        @method('DELETE')
                             <button type="submit" name="Delete" class="btn btn-danger">Delete</button>
                             </form>
                             <a href="/todos/{{ $listing->id }}/edit" class="btn btn-info float-right">Edit</a>   
                            </tr>
                            @endforeach
                        </table>
                        @else
                        <p>You don't have any Tickets yet</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
@endsection
               
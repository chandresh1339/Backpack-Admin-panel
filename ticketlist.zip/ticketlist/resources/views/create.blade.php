@extends('layouts.app')

@section('content')
<h1>Create NEW Ticket</h1>

                  <form method="post" action="/todo/store">
	                    {{ @csrf_field() }}
					               		<div class="form-group">
									    <label for="title">Enter your title</label>
									    <input type="text" class="form-control" id="title" name="title" placeholder="Enter your title" value="{{ old('title')}}">
							    	          </div>
							    	          <div class="form-group">
									    <label for="content">Enter your content</label>
									    <input type="text" class="form-control" id="content" name="content" placeholder="Enter your content" value="{{ old('content')}}">
							    	          </div>
							    	          <div class="form-group">
									    <label for="due">Due</label>
									    <input type="text" class="form-control" id="due" name="due" placeholder="Due..." value="{{ old('due')}}">
							    	          </div>

							    	             <div class="form-group">
									    <label for="due">Ticket#</label>
									    <input type="text" class="form-control" id="ticket" disabled name="ticket" placeholder="Due..." value="@php
                $randomid = alpha();
                print_r($randomid);
            @endphp">
							    	          </div>
										 			 <button type="submit" class="btn btn-primary">Submit</button>
						</form>

@endsection



<?php $__env->startSection('content'); ?>
<h1>Create NEW Ticket</h1>

                  <form method="post" action="/todo/store">
	                    <?php echo e(@csrf_field()); ?>

					               		<div class="form-group">
									    <label for="title">Enter your title</label>
									    <input type="text" class="form-control" id="title" name="title" placeholder="Enter your title" value="<?php echo e(old('title')); ?>">
							    	          </div>
							    	          <div class="form-group">
									    <label for="content">Enter your content</label>
									    <input type="text" class="form-control" id="content" name="content" placeholder="Enter your content" value="<?php echo e(old('content')); ?>">
							    	          </div>
							    	          <div class="form-group">
									    <label for="due">Due</label>
									    <input type="text" class="form-control" id="due" name="due" placeholder="Due..." value="<?php echo e(old('due')); ?>">
							    	          </div>

							    	             <div class="form-group">
									    <label for="due">Ticket#</label>
									    <input type="text" class="form-control" id="ticket" disabled name="ticket" placeholder="Due..." value="<?php
                $randomid = alpha();
                print_r($randomid);
            ?>">
							    	          </div>
										 			 <button type="submit" class="btn btn-primary">Submit</button>
						</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\todolist\resources\views/create.blade.php ENDPATH**/ ?>
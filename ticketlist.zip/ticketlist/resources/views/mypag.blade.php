
@extends('layouts.app')

@section('content')
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		
		.page-item{

			display:inline-block;
			padding: 10px;
		}
	</style>
	<title>Welcome</title>
</head>
<body>
<div>

	@foreach($data as $item)
	<div class="card m-2">
	<h2> {{$item->title}}</h2>

		<h2><div class="badge badge-success mt-4">{{ $item->ticket}}</div>
		</h2>

		<span class="badge badge-danger">{{$item->due}}</span>
</div>
@endforeach
</div>

<div>{{ $data->links()}}
	</div>

</body>
</html>

@endsection
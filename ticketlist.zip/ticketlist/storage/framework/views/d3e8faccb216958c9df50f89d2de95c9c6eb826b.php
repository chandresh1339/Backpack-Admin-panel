


<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		
		.page-item{

			display:inline-block;
			padding: 10px;
		}
	</style>
	<title>Welcome</title>
</head>
<body>
<div>

	<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="card m-2">
	<h2> <?php echo e($item->title); ?></h2>

		<h2><div class="badge badge-success mt-4"><?php echo e($item->ticket); ?></div>
		</h2>

		<span class="badge badge-danger"><?php echo e($item->due); ?></span>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div><?php echo e($data->links()); ?>

	</div>

</body>
</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\todolist\resources\views/mypag.blade.php ENDPATH**/ ?>
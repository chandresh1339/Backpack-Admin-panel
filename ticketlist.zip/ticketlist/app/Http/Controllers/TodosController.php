<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Todo;
use Illuminate\Support\Facades\Auth;


class TodosController extends Controller
{
    
      public function __construct()
        {
            $this->middleware('auth',['except'=>['index','show']]);
        }


     
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


       $todos=Todo::orderBy('created_at','asc')->get();
       //dd($todos);
       return view('index')->with('todos',$todos);

       $data=DB::table('todos')->paginate(5);
        return view('mypag',['data'=>$data]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,
            ['title'=>'required',
              'content'=>'required',
              'due'=>'required'
             
            ]
        );

        $todo=new Todo();

//Get the currently authenticated user id
    $todo->user_id=Auth::id();


         $todo->title=$request->input('title');
         $todo->content=$request->input('content');
         $todo->due=$request->input('due');
         //Return the alpha() function from helper.php file  to pull the random ticket id and save into database.
        $todo->ticket = alpha();
         $todo->save();

         return redirect('/')->with('success','Ticket created successfully');
           
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //Find the id of current attributes of an array
     $todo = Todo::find($id);
  
  //Returns the show() function with table name 'todo'
 return view('show')->with('todos',$todo);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
    
    dd($id);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function tune()
    {
       $randomid=alpha();

        $result='';

        return view('tune',compact('result'));
    }

  public function search($id)
  {
   //Find the id of current attributes of an array
     $todo = Todo::find($id);

      //Returns the show() function with table name 'todo'
 return view('index')->with('todos',$todo);
  }


  
}

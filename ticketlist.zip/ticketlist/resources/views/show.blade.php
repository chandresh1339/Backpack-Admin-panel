@extends('layouts.app')


			@section('content')
		
		      
							<a href="/" class="btn btn-secondary mt-2">Go Back</a>
							
							<h1>{{$todos->title}}</h1>

							<div class="badge badge-danger">{{ $todos->due}}</div>
							<hr>
							<div class="badge badge-pill badge-dark mt-2">{{ $todos->ticket}}</div>
							<p>{{ $todos->content }}</p>

						
							
			

				@endsection



<?php $__env->startSection('content'); ?>

<body>


<form action="" method="GET" class="form-inline pull-right">
<?php echo csrf_field(); ?>
            <div class="form-group form-group-lg has-feedback">

                <label class="sr-only" for="search">Search</label>
                <input type="text" class="form-control" name="search" id="search" placeholder="Search">

                <span class="glyphicons glyphicons-xl glyphicons-group form-control-feedback"></span>

            <button type="submit" class="btn btn btn-primary">
            <span class="glyphicons glyphicons-search" aria-hidden="true"></span>Search
            </button>
</div>
        </form>

        <?php $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="card m-2">
	<h2> <?php echo e($item->title); ?></h2>

		<h2><div class="badge badge-success mt-4"><?php echo e($item->ticket); ?></div>
		</h2>

		
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

    </body>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\todolist\resources\views/search.blade.php ENDPATH**/ ?>
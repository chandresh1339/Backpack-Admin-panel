


			<?php $__env->startSection('content'); ?>
		
		      
							<a href="/" class="btn btn-secondary mt-2">Go Back</a>
							
							<h1><?php echo e($todos->title); ?></h1>

							<div class="badge badge-danger"><?php echo e($todos->due); ?></div>
							<hr>
							<div class="badge badge-pill badge-dark mt-2"><?php echo e($todos->ticket); ?></div>
							<p><?php echo e($todos->content); ?></p>

						
							
			

				<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\todolist\resources\views/show.blade.php ENDPATH**/ ?>
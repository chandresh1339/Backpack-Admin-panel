@extends('layouts.app')
@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            @php
                $randomid = alpha();
                print_r($randomid);
            @endphp
        </div>
    </div>
</div>


@endsection


				   
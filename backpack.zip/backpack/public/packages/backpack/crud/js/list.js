/*
*
* Backpack Crud / List
*
*/

jQuery(function($){

    'use strict';
});
